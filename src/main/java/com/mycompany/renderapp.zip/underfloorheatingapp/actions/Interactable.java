/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.underfloorheatingapp.actions;

/**
 *
 * @author Antoine
 */
public interface Interactable {
	public boolean isInteracted();
	public void action();
}
