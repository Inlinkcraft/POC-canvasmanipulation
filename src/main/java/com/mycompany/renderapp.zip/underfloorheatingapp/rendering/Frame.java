/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.underfloorheatingapp.rendering;

import com.mycompany.underfloorheatingapp.rendering.renderelements.RenderElement;
import java.awt.Graphics2D;

/**
 *
 * @author Antoine
 */
public class Frame {
	
	private State status;
	Renderable[] renderables;
	Graphics2D canvas;

	public Frame(Renderable[] renderables){
		this.status = State.LOCK;
		this.renderables = renderables;
		this.status = State.READY;
	}

	public State getStatus() {
		return status;
	}

	public Renderable[] getRenderables() {
		return renderables;
	}

	public void setStatus(State status) {
		this.status = status;
	}

	public void setRenderables(Renderable[] renderables) {
		this.renderables = renderables;
	}

	public void render() {
		for (Renderable renderable: renderables){
			//Should add sorting here
			for (RenderElement renderElm : renderable.getRenderElements()){
				renderElm.render(canvas);
			}
		}
	}
	
	public enum State{
		LOCK,
		READY,
		RENDERED
	}
}
